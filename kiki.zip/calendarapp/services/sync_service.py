from .file_processor import FileProcessor
from django.core.exceptions import ValidationError

class SyncService:
    @staticmethod
    def sync_edusoft_schedule(user, username):
        """
        Sync Edusoft schedule with calendar events
        """
        try:
            processor = FileProcessor(user)
            result = processor.process_edusoft_zip(username)
            
            if result['status'] == 'success':
                return {
                    'status': 'success',
                    'message': result['message'],
                    'data': {
                        'events_created': result['events_created']
                    }
                }
            else:
                raise ValidationError(result['message'])

        except Exception as e:
            return {
                'status': 'error',
                'message': f'Failed to sync Edusoft schedule: {str(e)}'
            }

    @staticmethod
    def sync_blackboard_tasks(user, username):
        """
        Sync Blackboard assignments with tasks
        """
        try:
            processor = FileProcessor(user)
            result = processor.process_blackboard_csv(username)
            
            if result['status'] == 'success':
                return {
                    'status': 'success',
                    'message': result['message'],
                    'data': {
                        'tasks_created': result['tasks_created']
                    }
                }
            else:
                raise ValidationError(result['message'])

        except Exception as e:
            return {
                'status': 'error',
                'message': f'Failed to sync Blackboard tasks: {str(e)}'
            }