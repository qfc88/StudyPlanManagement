from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
from termcolor import colored
import pandas as pd
from io import StringIO
import os
import shutil
import time
import json
import logging

class EdusoftScraper:
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.base_dir = os.path.join('media', 'edusoftweb')
        os.makedirs(self.base_dir, exist_ok=True)
    start_time = time.time()
    download_path = None
    async def scrape(self):
        try:
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(headless=True)
                page = await browser.new_page()
                
                # Login
                await page.goto('https://edusoftweb.hcmiu.edu.vn/')
                if await page.is_visible('input#ContentPlaceHolder1_ctl00_txtCaptcha'):
                    print(colored('Captcha detected', 'red', attrs=['bold']))
                    captcha_text = await page.inner_text("span#ContentPlaceHolder1_ctl00_lblCapcha")
                    print(colored('Captcha text: ' + captcha_text, 'red', attrs=['bold']))
                    await page.fill('input#ContentPlaceHolder1_ctl00_txtCaptcha', captcha_text)
                    await page.click('input#ContentPlaceHolder1_ctl00_btnXacNhan')
                    
                await page.fill('input#ContentPlaceHolder1_ctl00_ucDangNhap_txtTaiKhoa', username)
                await page.fill('input#ContentPlaceHolder1_ctl00_ucDangNhap_txtMatKhau', password)
                await page.click('input#ContentPlaceHolder1_ctl00_ucDangNhap_btnDangNhap')

                print(colored('Logged in ' + username, 'cyan', attrs=['bold']))
                
                # Check if login was successful
                try:
                    await page.wait_for_selector('span#Header1_Logout1_lblNguoiDung', timeout=5000)
                except:
                    return json.dumps({
                        'status': 'error',
                        'message': 'Login failed - Invalid credentials or connection error',
                        'processing_time': time.time() - start_time
                    })

                await page.goto('https://edusoftweb.hcmiu.edu.vn/default.aspx?page=thoikhoabieu&sta=1')
                await page.click('input#ContentPlaceHolder1_ctl00_rad_ThuTiet')
                await page.wait_for_selector('span#Header1_Logout1_lblNguoiDung')

                select_locator = page.locator("#ContentPlaceHolder1_ctl00_ddlChonNHHK")
                semester_options = await select_locator.evaluate("""el => 
                    Array.from(el.options).map(option => ({
                        value: option.value,
                        text: option.text
                    }))
                """)
                
                SemesterOptions = [option['value'] for option in semester_options]
                print(colored(f'Found {len(SemesterOptions)} semesters', 'green', attrs=['bold']))

                for semester in SemesterOptions:
                    print(colored('Selecting semester ' + semester, 'cyan', attrs=['bold']))
                    await select_locator.select_option(value=semester)
                    await page.wait_for_selector('span#Header1_Logout1_lblNguoiDung')
                    print(colored('Begin to scrape' , 'cyan', attrs=['bold']))

                    response = await page.content()
                    soup = BeautifulSoup(response, 'html.parser')
                    table = soup.find_all('table', {'class': 'body-table'})
                    
                    timetable = pd.DataFrame({})
                    for i in range(0, len(table)):
                        df = pd.read_html(StringIO(str(table)))[i]
                        if df is not None:
                            timetable = timetable._append(df)

                    path = os.path.join("edusoftweb", username, "files")
                    if not os.path.exists(path):
                        os.makedirs(path, mode=0o777)
                    path_user = f"{username}_{semester}_edusoftweb.csv"
                    timetable.to_csv(os.path.join(path, path_user), index=False, encoding='utf-8-sig')

                await browser.close()
                
                # Create zip file
                download_path = os.path.join("edusoftweb", username, f"{username}_timetable")
                shutil.make_archive(download_path, 'zip', path)
                
                processing_time = time.time() - start_time
                print("--- %s seconds ---" % processing_time)
                
                return json.dumps({
                    'status': 'success',
                    'file_path': download_path + ".zip",
                    'processing_time': processing_time,
                    'semesters_processed': len(SemesterOptions)
                })

        except Exception as e:
            error_message = str(e)
            print(colored(f'Error: {error_message}', 'red', attrs=['bold']))
            
            return json.dumps({
                'status': 'error',
                'message': error_message,
                'processing_time': time.time() - start_time
            })

        finally:
            # Cleanup old files if there was an error
            if download_path and os.path.exists(download_path + ".zip"):
                try:
                    os.remove(download_path + ".zip")
                except:
                    pass